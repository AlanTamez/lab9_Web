function funcget(){
    let url = "/blogs/api/list-blogs/";
   	let settings = {
        	method : "GET",
        	mode : 'no-cors',
        	headers : {
            'Content-Type' : 'application/json'
        }
	};
	//console.log("todo bien");

    fetch(url, settings)
        .then(response => {
            if (response.ok){
                return response.json();
            }
            throw Error("something went wrong");
        })
        .then(responseJSON => {
            //console.log("todo bien");
            display(responseJSON);

        });
}

function display(data){
	$('#responses').html("");
    for(let i = data.blogs.length - 1; i >= 0; i--){
        $('#responses').append(`
            <li>
                <p><b>Title:</b> ${data.blogs[i].title}</p>
                <p><b>Author:</b> ${data.blogs[i].author}</p>
                <p><b>Content:</b> ${data.blogs[i].content}</p>
                <p><b>Publish Date:</b> ${data.blogs[i].publishDate}</p>
                <p><b>Id:</b> ${data.blogs[i].id}</p>
            </li>
        `)
    }
}

function getAuthor(author){
    let url = `/blogs/api/list-blogs/${author}`;
   	let settings = {
        	method : "GET",
        	mode : 'no-cors',
        	headers : {
            'Content-Type' : 'application/json'
        }
	};
	//console.log("todo bien");

    fetch(url, settings)
        .then(response => {
            if (response.ok){
                return response.json();
            }
            throw Error("something went wrong");
        })
        .then(responseJSON => {
            //console.log("todo bien");
            display(responseJSON);
        });
}

function addPost(title, author, date, cont){
	let data = {
		title : title,
        content : cont,
        author : author,
        publishDate : date
	};

	let url = './blogs/api/list-blogs';
	let settings = {
        method : 'POST',
        headers : {
            'Content-Type' : 'application/json'
        },
        body : JSON.stringify(data)
    };

	fetch(url, settings)
		.then(response => {
			if (response.ok){
				return response.json();
			}
			else{
				return new Promise(function(resolve, reject){
					resolve(response.json());
				})
				.then(data =>{
					throw new Error(data.message);
				});
			}
		})
		.then(responseJSON => {
			funcget();
		})
		.catch(err => {
            alert(err.message);
		});
}

function deletePost(id){
    let url = `./blogs/api/list-blogs/${id}`;
    let settings = {
        method : 'DELETE',
        headers : {
            'Content-Type' : 'application/json'
        }
    }
    
    fetch(url, settings)
		.then(response => {
			if (response.ok){
				return response.json();
			}
			else{
				return new Promise(function(resolve, reject){
					resolve(response.json());
				})
				.then(data =>{
					throw new Error(data.message);
				});
			}
		})
		.then(responseJSON => {
			funcget();
		})
		.catch(err => {
            alert(err.message);
		});
}

function updatePost(id, title, content, author, date){
    let url = `./blogs/api/list-blogs/${id}`;
    let data = {
		title : title,
        content : content,
        author : author,
        publishDate : date
	};
    let settings = {
        method : 'PUT',
        headers : {
            'Content-Type' : 'application/json'
        },
        body : JSON.stringify(data)
    }

    fetch(url, settings)
		.then(response => {
			if (response.ok){
				return response.json();
			}
			else{
				return new Promise(function(resolve, reject){
					resolve(response.json());
				})
				.then(data =>{
					throw new Error(data.message);
				});
			}
		})
		.then(responseJSON => {
			funcget();
		})
		.catch(err => {
            alert(err.message);
		});
}

function watchForm(){
	$('#getall').on('click', function(event) {
		event.preventDefault();
		funcget();
	});

	$('#getauth').on('click', function(event){
        event.preventDefault();
        let author = $('#byauth').val();
        getAuthor(author);
    });

    $('#newPost').on('click', function(event){
    	let title = $('#newTitle').val();
    	let author = $('#newAuth').val();
    	let date = $('#newDate').val();
    	let cont = $('#newCont').val();
    	addPost(title, author, date, cont);
    });

    $('#delPost').on('click', function(event){
    	event.preventDefault();
    	pId = $('#delID').val();
    	deletePost(pId);
    });

    $('#edPost').on('click', function(event){
        event.preventDefault();
        let id = $('#edID').val();
        let title = $('#edTitle').val();
        let content = $('#newCont').val();
        let author = $('#edAuth').val();
        let date = $('#edDate').val();
        updatePost(id, title, content, author, date);    
    });
}

function initial(){
	$(funcget);
	$(watchForm);
}

$(initial);