const uuid = require('uuid');
const mongoose = require('mongoose');
mongoose.Promise = global.Promise;

//set attributes
let blogSchema = mongoose.Schema({
	id: {type: String, required: true, unique: true},			//unique is like primary key
    title: {type: String, required: true},
    content: {type: String, required: true},
    author: {type: String, required: true},
    publishDate: {type: String, required: true}
});

//creating the instance to use and edit the DB
let Blogs = mongoose.model('Blogs', blogSchema);

//this is an object and we create methods
const ListBlogs = {
	get : function(){
		return Blogs.find()
			.then(blogs => {
				return blogs;
			})
			.catch(err => {
				throw new Error(err);
			});
	},

	getByAuthor : function(author){
		return Blogs.find({author : author})
			.then(blogs => {
				return blogs;
			})
			.catch(err =>{
				throw new Error(err);
			});
	},

	post : function(newPost){
		return Blogs.create(newPost)
			.then(blogs => {
				return blogs;
			})
			.catch(err => {
				throw new Error(err);
			});
	},

	delete : function(pId){
		return Blogs.deleteOne({id: pId})
            .then(blogs => {
                return blogs;
            })
            .catch(err => {
                throw new Error(err);
            });
	},

	put : function(pId, pTitle, pContent, pAuthor, pDate){
		//console.log(pId);
		return Blogs.findByIdAndUpdate({id: pId}, {$set:{title: pTitle, content: pContent, author: pAuthor, publishDate: pDate}})
            .then(blogs => {
                return blogs;
            })
            .catch(err => {
                throw new Error(err);
            }); 
	}
}

//making it accesible
//this could be a database
module.exports = {ListBlogs};