const express = require('express');
//const bodyParser = require('body-parser');
//const jsonParser = bodyParser.json();

const router = express.Router();

const uuid = require('uuid');
//we need to specify we want to use the model here
const {ListBlogs} = require('./model');

router.get('/list-blogs', (req, res, next) => {
	//this particular endpoint will ask to the model
    ListBlogs.get()
        .then(blogs => {
            res.status(200).json({
                message : "Successfully sent the list of sports",
                status : 200,
                blogs : blogs
            });
        })
        .catch(err => {
            res.status(500).json({
                message : `internal server error`,
                status : 500
            });
            return next();
        });
});

router.get('/list-blogs/:author', (req, res, next) => {
	let blogauthor = req.params.author;

    ListBlogs.getByAuthor(blogauthor)
        .then(blogs => {
            res.status(200).json({
                message : "Successfully author found",
                status : 200,
                blogs : blogs
            });
        })
        .catch(err => {
            res.status(500).json({
                message : `internal server error`,
                status : 500
            });
            return next();
        });
});

router.post('/list-blogs', (req, res, next) => {
	
	let requiredFields = ['title', 'content', 'author', 'publishDate'];

	for (let i = 0; i < requiredFields.length; i++){
		let currentField = requiredFields[i];
		if (!(currentField in req.body)){
			res.status(406).json({
				message : `Missing field ${currentField} in body.`,
				status : 406
			}).send("Finish");
			return next();
		}
	}

	let objectToAdd = {
		id: uuid.v4(),
		title: req.body.title,
		content: req.body.content,
		author: req.body.author,
		publishDate: req.body.publishDate
	};

	ListBlogs.post(objectToAdd)
	   .then(blogs => {
            res.status(201).json({
                message : "The post was added successfully",
                status : 201,
                blogs : blogs
            });
        })
        .catch(err => {
            res.status(500).json({
                message : `Internal server error.`,
                status : 500
            });
            return next();
        });
});

router.delete('/list-blogs/:id', (req, res, next) =>{
	let pId = req.params.id;
   
    ListBlogs.delete(pId)
        .then(blogs => {
            res.status(200).json({
                message : "The post was deleted successfully",
                status : 200,
                blogs : blogs
            });
        })
        .catch(err => {
            res.status(404).json({
                message : "Post not found in the list.",
                status : 404
            });
            return next();
        });	
});

router.put('/list-blogs/:id', (req, res, next) =>{
	let postId = req.params.id;
	//console.log(postId);
	if (postId == undefined){
        res.status(406).json({
            message: "id not found in path",
            status: 406
        });
        return next();
    }	
   	
   	let postTitle = req.body.title;
    let postContent = req.body.content;
    let postAuthor = req.body.author;
    let postPublishDate = req.body.publishDate;
    
    ListBlogs.put(postId, postTitle, postContent, postAuthor, postPublishDate)
        .then(blogs => {
            res.status(200).json({
                message: "Successfully updated post",
                status: 200,
            });
        })
        .catch(err => {
            res.status(500).json({
                message: "id not found",
                status: 500,
            });
            return next();
        }); 
});

module.exports = router;