const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const app = express();
const jsonParser = bodyParser.json();

const {DATABASE_URL, PORT} = require('./config');

mongoose.Promise = global.Promise;
const uuid = require('uuid');
//Router
const blogRouter = require('./router')


app.use(express.static('public'));
app.use('/blogs/api', jsonParser, blogRouter);
let server;

function runServer(port, databaseUrl){
	return new Promise((resolve, reject) => {
		mongoose.connect(databaseUrl,
			//the err is a second parameter 
			err =>{
				if(err){
					return reject(err);	
				}
				else{
					server = app.listen(port, () =>{
						console.log('Your app is running in port ', port);
						resolve();
					})
					.on('error', err => {
						mongoose.disconnect();
						return reject(err);
					});
				}
			}
		);
	});
}

function closeServer(){
	return mongoose.disconnect()
		.then(() => {
			return new Promise((resolve, reject) =>{
				console.log('Closing the server');
				server.close(err => {
					if(err){
						return reject(err);
					}
					else{
						resolve();
					}
				});
			});
		});
}

runServer(PORT, DATABASE_URL)
    .catch(err => console.log(err));

//'mongodb://localhost/nombre del DB'
//runServer(8080, 'mongodb://localhost/sports')
//	.catch(err => console.log(err));

module.exports = {app, runServer, closeServer};